This font was created by Anfa.
It is for personal use only.  If you wish to use it commercially I ask for 
a one-time US $5 paypal payment to anfa67@yahoo.co.uk

Cheers! :)



